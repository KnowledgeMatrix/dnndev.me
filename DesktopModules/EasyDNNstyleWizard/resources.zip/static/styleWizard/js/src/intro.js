/*!
 * StyleWizard
 * www.easydnnsolutions.com/modules/easydnnstylewizard/
 *
 * Copyright 2013 EasyDNNsolutions.com
 * StyleWizard is developed by EasyDNNsolutions.com. It can be used only
 * as an integral part of EasyDNNsolutions.com modules. All unauthorized
 * copying or use of the code or parts of the code is prohibited.
 */

(function ($, window, document, undefined) {
	'use strict';
